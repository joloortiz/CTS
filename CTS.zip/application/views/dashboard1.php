<div id="header">
	
</div>
<h2>Dashboard</h2>
	<ul>
		<li><?php echo anchor("users", "Users")?></li>
		
	</ul>
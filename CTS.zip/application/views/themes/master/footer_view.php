</div> <!-- #content end -->
<footer>
 	<p>Page rendered in <strong>{elapsed_time}</strong> seconds</p>
</footer>
</body>
</html>
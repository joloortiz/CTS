<div id="right-area">
	<div id="main-content">

	</div>
</div>